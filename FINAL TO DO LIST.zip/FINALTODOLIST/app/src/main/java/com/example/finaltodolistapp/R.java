package com.example.finaltodolistapp;

public class R {
    public static Object layout;
    public static Object id;
}
